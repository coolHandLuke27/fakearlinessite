<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Fake Airlines</title>
<link rel="stylesheet" type="text/css" href="spicyBoi.css">
</head>

<body>

<?php
session_start();

$form_username = $_POST['form_username'];
$form_pass = $_POST['form_pass'];

$mysqli = new mysqli('localhost', 'root', '','hw3_db');
$mysqli2 = new mysqli('localhost', 'root', '','hw3_db');
$result = $mysqli->query("SELECT tb_fname FROM accounttable WHERE (tb_username = '$form_username') AND (tb_password = '$form_pass')");
$result2 = $mysqli2->query("SELECT * FROM accountbookings WHERE bk_username = '$form_username'");
if($result->num_rows == 0) {
     echo "<h1> Oops! </h1>";
     echo "Invalid username/password. Please try again.";
} else {
    $row = $result -> fetch_array(MYSQLI_ASSOC);
    $display_name = $row["tb_fname"];
    echo "<h1> Flight Bookings </h1>";
    echo "Hello, " .$display_name;
    echo "<br>";
    echo "<br>";
    echo "<br>";
    echo "<br>";
    echo "Current Flights:";
    $_SESSION['get_username'] = $form_username;

    if($result2->num_rows == 0) {
     echo "&nbsp;&nbsp; <strong> No flights booked. </strong>";
     } else {
     while($row2 = $result2 -> fetch_array(MYSQLI_ASSOC)){
          echo "<br>";
          echo "<br>";
          echo "<fieldset>";
          echo "Departing from: <strong>" .$row2['bk_depart']. "</strong>";
          echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
          echo "     Destination: <strong>" .$row2['bk_dest']. "</strong>";
          echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
          echo "     Date: <strong>" .$row2['bk_date']. "</strong>";
          echo "</fieldset>";
          }
     }
   ?>
   <br>
   <br>
   <br>
   <p> Book a flight:</p>
   <form action="bookFlight.html">
   <input id="buttonDesign" type="submit" value="Book" />
   </form> 
<?php
}
$mysqli->close();
?>

<br>
<br>
<br>
<br>
<div class="logostl">
<img src="logopolished.png" alt="Fake Airlines Logo" width="250" height="100">
<p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The contents of this website are fictional and for entertainment/education purposes only. | 2023 </p>
</div>

</body>
</html>