<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Fake Airlines</title>
<link rel="stylesheet" type="text/css" href="spicyBoi.css">
</head>

<body>

<?php

if(isset($_POST['form_username']))
{
$con = mysqli_connect('localhost', 'root', '','hw3_db');


$form_username = $_POST['form_username'];
$form_pass = $_POST['form_pass'];
$form_fname = $_POST['form_fname'];
$form_lname = $_POST['form_lname'];
$form_email = $_POST['form_email'];
$form_address = $_POST['form_address'];
$form_city = $_POST['form_city'];
$form_state = $_POST['form_state'];
$form_zip = $_POST['form_zip'];


$sql = "INSERT INTO `accounttable` (`tb_username`, `tb_password`, `tb_fname`, `tb_lname`, `tb_email`, `tb_address`, `tb_city`, `tb_state`, `tb_zip`) VALUES ('$form_username', '$form_pass', '$form_fname', '$form_lname', '$form_email', '$form_address', '$form_city', '$form_state', '$form_zip')";

$rs = mysqli_query($con, $sql);
if($rs)
{
	echo "<h1> Account Created! </h1>";
	echo "Thanks, " .$form_fname. ". ";
	echo "Head log in page to book flights.";
	echo "<br>";
	echo "<br>";
	echo "<br>";
	echo "<br>";
	?>
	<form action="login.html">
    <input id="buttonDesign" type="submit" value="Go" />
    </form>
    <?php
}
}
else
{
	echo "Are you a genuine visitor?";
	
}
?>

<br>
<br>
<br>
<br>
<div class="logostl">
<img src="logopolished.png" alt="Fake Airlines Logo" width="250" height="100">
<p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The contents of this website are fictional and for entertainment/education purposes only. | 2023 </p>
</div>

</body>
</html>