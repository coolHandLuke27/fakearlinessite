<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Fake Airlines</title>
<link rel="stylesheet" type="text/css" href="spicyBoi.css">
</head>

<body>

<?php

session_start();

if(isset($_POST['form_depart']))
{
$con = mysqli_connect('localhost', 'root', '','hw3_db');


$inp_username = $_SESSION['get_username'];

$form_depart = $_POST['form_depart'];
$form_dest = $_POST['form_dest'];
$form_date = $_POST['form_date'];

$sql = "INSERT INTO `accountbookings` (`bk_username`, `bk_depart`, `bk_dest`, `bk_date`) VALUES ('$inp_username', '$form_depart', '$form_dest', '$form_date')";

$rs = mysqli_query($con, $sql);
if($rs)
{
	?>
    <h1>Flight Booked! </h1>
    <br>
    <br>
    <br>
    <br>
    <div class="logostl">
    <img src="logopolished.png" alt="Fake Airlines Logo" width="250" height="100">
    <p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;The contents of this website are fictional and for entertainment/education purposes only. | 2023 </p>
    </div>
    <?php 
}
}
else
{
	echo "Are you a genuine visitor?";
	
}
?>

</body>
</html>